<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listings</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<script>
        // JavaScript to open print settings when the page loads
        window.onload = function() {
            window.print();
        };
    </script>
<?php if(count($listings) > 0): ?>
<div>
<table class="table table-responsive">
  <thead class="thead-dark">
    <tr>
		 <th scope="col" >Client</th>
		 <th scope="col" >Kroki&nbsp;No</th>
		 <th scope="col" >Title</th>
		 <th scope="col" >Size</th>
		 <th scope="col" >Location</th>
		 <th scope="col" >Type</th>
		 <th scope="col" >Amount</th>
		 <th scope="col" >Status</th>
		 <th scope="col" >#&nbsp;Bedrooms</th>
		 <th scope="col" >#&nbsp;Toilets</th>
		 <th scope="col" >#&nbsp;Majlis</th>
		 <th scope="col" >#&nbsp;Floors</th>
		 <th scope="col" >#&nbsp;Kitchens</th>
		 <th scope="col" >Date</th>
		</tr>
  </thead>
  <tbody class="bg-white" >
    <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td ><?php echo e($listing->first_name); ?> <?php echo e($listing->middle_name); ?> <?php echo e($listing->last_name); ?></td>
      <td ><?php echo e($listing->serial_no); ?></td>
      <td ><?php echo e($listing->title); ?></td>
      <td ><?php echo e($listing->size); ?></td>
      <td ><?php echo e($listing->location); ?></td>
      <td ><?php echo e($listing->type); ?></td>
      <td ><?php echo e($listing->amount); ?></td>
      <td ><?php echo e($listing->status); ?></td>
	  <td ><?php echo e($listing->title); ?></td>
	  <td ><?php echo e($listing->no_toilets); ?></td>
	  <td ><?php echo e($listing->no_majlis); ?></td>
	  <td ><?php echo e($listing->no_floors); ?></td>
	  <td ><?php echo e($listing->no_kitchens); ?></td>
	  <td ><?php echo e(date_format($listing->created_at,'d M Y')); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
<?php else: ?>
 <div class="d-flex justify-content-center align-items-center w-100" style="height: calc(100vh - 500px)" >
   <h4>No Listings Found!</h4>
 </div>
<?php endif; ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\Dar Al-Iskan Real Estate\resources\views/pdf/listingsPdf.blade.php ENDPATH**/ ?>