
<?php $__env->startSection('main'); ?>
<?php $__env->startPush('title'); ?>
<title><?php echo app('translator')->get('Add User'); ?></title>
<?php $__env->stopPush(); ?>

<script>
 $(document).ready(function () {
  // Intercept the form submission
  $('#client-form').submit(function () {
   // Show the loader
   $('#loader').removeClass('d-none');
   $('#form-btn-text').addClass('d-none');
  });
 });
</script>


<div class="dashborad--content">
				
<div class="breadcrumb-area">
  <h3 class="title"><?php echo app('translator')->get('Add User'); ?></h3>
  <ul class="breadcrumb">
      <li>
        <a href="<?php echo e(url('/user/dashboard')); ?>"><?php echo app('translator')->get('Dashboard'); ?></a>
      </li>
      <li><?php echo app('translator')->get('Add User'); ?></li>
  </ul>
</div>
<?php if(session()->has('success')): ?>
<div>
 <h5 class="text-success text-center mb-2" ><?php echo e(session()->get('success')); ?></h5>
</div>
<?php endif; ?>

<div class="dashboard--content-item">
    <div id="request-form">
    <?php echo csrf_field(); ?>
    <div class="profile--card">
          <form id="client-form" class="row gy-4" action="<?php echo e(url('/admin/create-user')); ?>" method="post">
            <?php echo csrf_field(); ?>
              <div class="col-sm-6 col-lg-4 col-xxl-4">
                <label for="name" class="form-label"><?php echo app('translator')->get('User Name'); ?></label>
                 <?php $__errorArgs = ['user_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="text" id="user_name" name="user_name" class="form-control" value="">
              </div>
              <div class="col-sm-6 col-lg-4 col-xxl-4">
               <label for="email" class="form-label"><?php echo app('translator')->get('Password'); ?></label>
               <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
               <input type="password" id="password" name="password" class="form-control" value="" >
              </div>
              <div class="col-sm-6 col-lg-4 col-xxl-4">
               <label for="email" class="form-label"><?php echo app('translator')->get('Re-Type Password'); ?></label>
               <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
               <input type="password" id="password_confirmation" name="password_confirmation" class="form-control" value="" >
              </div>

              <div class="col-sm-6 col-xxl-4">
                  <label for="phone" class="form-label"><?php echo app('translator')->get('Phone'); ?></label>
                  <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <div class="input-group">
                      <input type="text" name="phone" id="phone" class="form-control" value="">
                  </div>
              </div>
              <div class="col-sm-6 col-xxl-4">
                  <label for="phone" class="form-label"><?php echo app('translator')->get('Email'); ?></label>
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <div class="input-group">
                      <input type="text" name="email" id="phone" class="form-control" value="">
                  </div>
              </div>

              <div class="col-sm-12">
                  <div class="text-end">
                    <button type="submit" class="cmn--btn"><span id="form-btn-text" class="" ><?php echo app('translator')->get('Add'); ?></span> <div id="loader" class="d-none">
                     <div class="spinner-border" role="status">
                             <span class="sr-only">Loading...</span>
                         </div>
                     </div>
                    </button>
                  </div>
              </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminDashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dar Al-Iskan Real Estate\resources\views/adminDashboard/AddUser.blade.php ENDPATH**/ ?>