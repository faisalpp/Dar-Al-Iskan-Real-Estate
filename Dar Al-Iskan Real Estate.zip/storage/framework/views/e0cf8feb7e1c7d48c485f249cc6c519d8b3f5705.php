
<?php $__env->startSection('main'); ?>
<?php $__env->startPush('title'); ?>
<title>Add Client</title>
<?php $__env->stopPush(); ?>
<div class="dashborad--content">
				
<div class="breadcrumb-area">
  <h3 class="title">Add Client</h3>
  <ul class="breadcrumb">
      <li>
        <a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a>
      </li>
      <li>Add Client</li>
  </ul>
</div>
<?php if(session()->has('success')): ?>
<div>
 <h5 class="text-success text-center mb-2" ><?php echo e(session()->get('success')); ?></h5>
</div>
<?php endif; ?>
<div class="dashboard--content-item">
    <div id="request-form">
    <?php echo csrf_field(); ?>
    <div class="profile--card">
          <form class="row gy-4" action="<?php echo e(url('/admin/profile-update')); ?>" method="post">
            <?php echo csrf_field(); ?>
              <div class="col-sm-6 col-xxl-4">
                <label for="name" class="form-label">First Name</label>
                <input type="text" id="name" name="first_name" autocomplete="title" class="form-control" value="">
              </div>
              <div class="col-sm-6 col-xxl-4">
               <label for="email" class="form-label">last Name</label>
               <input type="text" id="email" name="last_name" autocomplete="size" class="form-control" value="" >
              </div>

              <div class="col-sm-6 col-xxl-4">
                  <label for="phone" class="form-label">Phone</label>
                  <div class="input-group">
                      <input type="text" autocomplete="phone" name="phone" id="phone" class="form-control" value="">
                  </div>
              </div>

              <div class="col-sm-6 col-xxl-4">
                  <label for="phone" class="form-label">Client Type</label>
                  <div class="input-group">
                  <select class="form-control">
                    <option>VIP</option>
                    <option>General</option>
                  </select>    
                  <!-- <input type="" autocomplete="phone" name="phone" id="phone" class="form-control" value=""> -->
                  </div>
              </div>

              <div class="col-sm-12">
                  <div class="text-end">
                      <button type="submit" class="cmn--btn">Add</button>
                  </div>
              </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminDashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RBMS\resources\views/adminDashboard/AddClient.blade.php ENDPATH**/ ?>