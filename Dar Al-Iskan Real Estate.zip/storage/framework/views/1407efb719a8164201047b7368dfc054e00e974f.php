
<?php $__env->startSection('main'); ?>
<?php $__env->startPush('title'); ?>
<title>Withdraw</title>
<?php $__env->stopPush(); ?>
<div class="dashborad--content">
				<div class="breadcrumb-area">
  <h3 class="title">Withdraw</h3>
  <ul class="breadcrumb">
      <li>
        <a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a>
      </li>

      <li>Withdraw</li>
  </ul>
</div>
<?php if(session()->has('error')): ?>
<div>
    <h5 class="text-danger text-center mb-2" ><?php echo e(session()->get('error')); ?></h5>
</div>
<?php endif; ?>
<?php if(session()->has('success')): ?>
<div>
 <h5 class="text-success text-center mb-2" ><?php echo e(session()->get('success')); ?></h5>
</div>
<?php endif; ?>
<script>
// Set the date we're counting down to


function calc() {
  
  let fee = document.getElementById('fee');
  let amount = document.getElementById('amount');
  let total = document.getElementById('total');
   let totall = (fee.value / 100) * amount.value;        
   total.value = (amount.value - totall).toFixed(2) ;
  console.log(fee.value)
};

</script>
<div class="dashboard--content-item">
  <div class="row g-3">
    <div class="col-12">
      <div class="card default--card">
        <div class="card-body">
          <form id="request-form" action="<?php echo e(url('/user/withdraw-request')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row gy-3 gy-md-4">
                                      <div class="col-sm-12">
                    <div class="form-group">
                      <label class="form-label required">Amount</label>
                      <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                       <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      <input name="aount" onchange="calc()" id="amount" class="form-control " autocomplete="off" type="number" >
                    </div>
                  </div>
                  <div class="col-sm-6 col-xxl-4">
                  <label for="name" class="form-label">Withdraw Fee</label>
                  <?php $__errorArgs = ['wihdraw_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <div class="input-group input--group">
                       <input type="number" name="withdraw_fee" readonly class="form-group-input form-control form--control bg--section" value="<?php echo e($mplan->withdraw_fee); ?>" id="fee">
                          <button type="button" class="input-group-text">%</button>
                      </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="form-label required">You Recieve </label>
                      <input name="amount" readonly id="total" class="form-control " autocomplete="off"  type="number" >
                    </div>
                  </div>
                  <div class="col-sm-12">
                    <div class="form-group">
                      <label class="form-label required">Receiver Account Number</label>
                      <?php $__errorArgs = ['wallet_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                       <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      <input name="wallet_address" id="accountemail" class="form-control " autocomplete="off" type="text">
                    </div>
                  </div>

                  <div class="col-sm-12">
                  <label for="name" class="form-label">Bank Name</label>
                  <select name="bank_name" class="form-control" >
                    <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($gateway->bank_name); ?>"><?php echo e($gateway->bank_name); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>         
                  </div>

                  <div class="col-sm-12">
                    <div class="form-group">
                     <label class="form-label required">Account Holder Name</label>
                     <?php $__errorArgs = ['acc_holder_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     <input name="acc_holder_name" id="account_name" class="form-control " autocomplete="off" placeholder="Jhon Doe" type="text">
                     </div>
                  </div>



                  <div class="col-sm-12">
                    <label class="form-label d-none d-sm-block">&nbsp;</label>
                    <button type="submit" class="cmn--btn bg--primary submit-btn w-100 border-0">Wihdraw Now</button>

                  </div>
                </div>

            </form>
        </div>
      </div>
  </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('userDashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RBMS\resources\views\userDashboard\withdraw.blade.php ENDPATH**/ ?>