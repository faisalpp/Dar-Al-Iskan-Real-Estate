
<?php $__env->startSection('main'); ?>
<?php $__env->startPush('title'); ?>
<title>Investment Plans</title>
<?php $__env->stopPush(); ?>
<div class="dashborad--content">
				<div class="breadcrumb-area">
    <h3 class="title">Investment Plans</h3>
    <ul class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a>
        </li>
        <li>Investment Plans</li>
    </ul>
</div>
<?php if(session()->has('error')): ?>
<div>
    <h5 class="text-danger text-center mb-2" ><?php echo e(session()->get('error')); ?></h5>
</div>
<?php endif; ?>
<?php if(session()->has('success')): ?>
<div>
 <h5 class="text-success text-center mb-2" ><?php echo e(session()->get('success')); ?></h5>
</div>
<?php endif; ?>

<script>
        // Wrap your JavaScript code in a DOMContentLoaded event handler
        document.addEventListener("DOMContentLoaded", function() {
            var items = <?php echo json_encode($active_plans); ?>;
            function updateCountdowns() {
                var now = new Date();
                
                items.forEach(function(item) {
                    var targetDate = new Date(item.expiration_date);
                    var timeRemaining = targetDate - now;
                    
                    var days = Math.floor(timeRemaining / (1000 * 60 * 60 * 24));
                    var hours = Math.floor((timeRemaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                    var minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));
                    var seconds = Math.floor((timeRemaining % (1000 * 60)) / 1000);
                    console.log(days)

                    document.getElementById(`countdown-${item.title}`).innerHTML = days + "d " + hours + "h " + minutes + "m " + seconds + "s";
                });
            }

            setInterval(updateCountdowns, 1000);
            updateCountdowns(); // Initial call to avoid delay
        });
    </script>

<div class="dashboard--content-item">
    <div class="pricing--wrapper row g-3 g-md-4 g-lg-3 g-xxl-4">
        <?php if(isset($membership) && $membership->status === 'APPROVED'): ?>
        <?php $__currentLoopData = $active_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $active_plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-sm-6 col-md-6">
                        <div class="plan__item">
                            <div class="plan__item-header">
                                <div class="left">
                                    <h5 class="title"><?php echo e($active_plan['title']); ?></h5>
                                    <span><?php echo e($active_plan['slogan']); ?></span>
                                </div>
                                <div class="right">
                                    <img src="<?php echo e(url('/')); ?>/plans/<?php echo e($active_plan['image']); ?>" />
                                </div>
                            </div>
                            <div class="plan__item-body">
                                <ul>
                                    <li>
                                        <span class="name">Profit</span>
                                        <span class="info">
                                            Daily
                                        </span>
                                    </li>
                                    
                                    <li>
                                        <span class="name ">Daily Income</span>
                                        <span class="info">
                                            Rs.<?php echo e($active_plan['profit_amount']); ?>

                                        </span>
                                    </li>
                                    <li>
                                        <span class="name ">Duration</span>
                                        <span class="info">
                                            <?php echo e($active_plan['duration']); ?> Days
                                        </span>
                                    </li>
                                    <li>
                                        <span class="name ">Total Income</span>
                                        <span class="info">
                                            Rs.<?php echo e(number_format($active_plan['profit_amount'] * $active_plan['duration'],0,',',',')); ?>

                                        </span>
                                    </li>
                                    <li>
                                        <span class="name">Price</span>
                                        <span class="info">
                                        <?php echo e($active_plan['coins']); ?> <img src="<?php echo e(url('/coin.png')); ?>" style="width:30px" />
                                        </span>
                                    </li>
                                </ul>
                                
                                <a class="cmn--btn w-100 invest-plan" style="background-color:red !important">
                                <!-- <?php echo e($active_plan['expiration_date']->format('j F,Y')); ?> -->
                                <p class="my-2" style="color:white" id="countdown-<?php echo e($active_plan['title']); ?>"></p>
                                </a>
                            </div>
                </div>
      </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
        
        <?php $__currentLoopData = $gnp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nplan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-sm-6 col-md-6">
                        <div class="plan__item">
                            <div class="plan__item-header">
                                <div class="left">
                                    <h5 class="title"><?php echo e($nplan->title); ?></h5>
                                    <span><?php echo e($nplan->slogan); ?></span>
                                </div>
                                <div class="right">
                                    <img src="<?php echo e(url('/')); ?>/plans/<?php echo e($nplan->image); ?>" />
                                </div>
                            </div>
                            <div class="plan__item-body">
                                <ul>
                                    <li>
                                        <span class="name">Profit</span>
                                        <span class="info">
                                            Daily
                                        </span>
                                    </li>
                                    
                                    <li>
                                        <span class="name ">Daily Income</span>
                                        <span class="info">
                                            Rs.<?php echo e($nplan->profit_amount); ?>

                                        </span>
                                    </li>
                                    <li>
                                        <span class="name ">Duration</span>
                                        <span class="info">
                                            <?php echo e($nplan->duration); ?> Days
                                        </span>
                                    </li>
                                    <li>
                                        <span class="name ">Total Income</span>
                                        <span class="info">
                                            Rs.<?php echo e(number_format($nplan->profit_amount * $nplan->duration,0,',',',')); ?>

                                        </span>
                                    </li>
                                    <li>
                                        <span class="name">Price</span>
                                        <span class="info">
                                        <?php echo e($nplan->coins); ?> <img src="<?php echo e(url('/coin.png')); ?>" style="width:30px" />
                                        </span>
                                    </li>
                                </ul>
                                
                                <a class="cmn--btn w-100 invest-plan" type="button" data-bs-toggle="modal" data-bs-target="#invest-modal<?php echo e($loop->index); ?>" data-title="Orbit" data-id="9" data-type="1" data-fixAmount="37000">
                                    BUY NOW
                                </a>
                            </div>
                        <!-- </div> -->
                    <!-- </div> -->
         
         <!-- Invest Modal -->
    <div class="modal fade" id="invest-modal<?php echo e($loop->index); ?>">
        <div class="modal-dialog">
            <div class="modal-content">
                <form class="investForm" action="<?php echo e(url('/user/invest-request')); ?>" enctype="multipart/form-data" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body p-4">
                        <h4 class="modal-title text-center plan-title"><?php echo e($nplan->title); ?> Plan</h4>
                        <div class="pt-3 pb-4">
                            <label for="amount" class="form-label" style="color:black" >Plan Amount</label>
                            <div class="input-group input--group">
                             <input type="hidden" name="plan_id" class="form-group-input form-control form--control bg--section" value="<?php echo e($nplan->plan_id); ?>" id="modalAmount">
                             <input type="number" readonly name="coins" class="form-group-input form-control form--control bg--section" value="<?php echo e($nplan->coins); ?>" id="modalAmount">
                                <button type="button" class="input-group-text"><img src="<?php echo e(url('/coin.png')); ?>" style="width:30px" /></button>
                            </div>
                        </div>
                        
                        <div class="pt-3 pb-4">
                            <label for="amount" class="form-label" style="color:black" >Plan Information</label>
                            <div class="flex flex-column input-group input--group">
                            <div><span style="color:red" >Daily Earning: Rs.<?php echo e($nplan->profit_amount); ?> </span></div> 
                            <div><span style="color:red" >Total Earning: Rs.<?php echo e($nplan->profit_amount * $nplan->duration); ?> </span></div> 
                            </div>
                        </div>
                        <div class="d-flex">
                            <button type="button" class="btn text-white shadow-none btn--danger me-2 w-50"
                                data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn shadow-none text-white btn--success w-50">Proceed</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

       </div>
      </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
    <?php endif; ?>
     
     <?php if(isset($membership) && $membership->status === 'PENDING'): ?>
       <div style="display:flex;justify-content:center;align-items:center;height:50vh;width:100%" >
           <h1>You'r Membership Request is in Processing...</h1>
       </div>
     <?php endif; ?>
     
    <?php if(empty($membership)): ?>
      
      
<section class="investment-plan-section overflow-hidden bg--gradient-light pb-100 pt-100">
        <div class="container">
            <div class="pricing--wrapper row g-3 g-md-4 g-lg-3 g-xxl-4 justify-content-center">
            <div class="col-lg-3 col-sm-6 col-md-6">
                        <div class="plan__item">
                            <div class="plan__item-header">
                                <div class="left">
                                    <h5 class="title"><?php echo e($mplan->title); ?></h5>
                                    <span><?php echo e($mplan->join_text); ?></span>
                                </div>
                            </div>
                            <div class="plan__item-body">
                                <ul>
                                    <li>
                                        <span class="name">Profit</span>
                                        <span class="info">
                                            Daily
                                        </span>
                                    </li>
                                    
                                    <li>
                                        <span class="name ">Daily Income</span>
                                        <span class="info">
                                            Rs.<?php echo e($mplan->daily_income); ?>

                                        </span>
                                    </li>
                                    <li>
                                        <span class="name ">Duration</span>
                                        <span class="info">
                                            <?php echo e($mplan->duration); ?> Days
                                        </span>
                                    </li>
                                    <li>
                                        <span class="name ">Monthly Income</span>
                                        <span class="info">
                                            Rs.<?php echo e(number_format($mplan->daily_income * 30,0,',',',')); ?>

                                        </span>
                                    </li>
                                    <li>
                                        <span class="name ">Total Income</span>
                                        <span class="info">
                                            Rs.<?php echo e(number_format($mplan->daily_income * $mplan->duration,0,',',',')); ?>

                                        </span>
                                    </li>
                                    <li>
                                        <span class="name">Unlock Fee</span>
                                        <span class="info">
                                         Rs.<?php echo e($mplan->investment); ?>

                                        </span>
                                    </li>
                                </ul>

                                <a class="cmn--btn w-100 invest-plan" href="<?php echo e(url('/user/unlock-plans')); ?>" >
                                    BUY NOW
                                </a>
                            </div>
                        </div>
                    </div>

     <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('userDashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RBMS\resources\views\userDashboard\plans.blade.php ENDPATH**/ ?>