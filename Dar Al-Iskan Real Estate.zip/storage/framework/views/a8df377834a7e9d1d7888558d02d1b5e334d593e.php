
<?php $__env->startSection('main'); ?>
<?php $__env->startPush('title'); ?>
<title>Referrals</title>
<?php $__env->stopPush(); ?>
<div class="dashborad--content">
				<div class="breadcrumb-area">
    <h3 class="title">My Referrals</h3>
    <ul class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a>
        </li>
        <li>My Referrals</li>
    </ul>
</div>

<div class="dashboard--content-item">
    <div class="table-responsive table--mobile-lg">
        <table class="table bg--body">
            <thead>
                <tr>
                    <tr>
                        <th>Full Name</th>
                        <th>User Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Joined At</th>
                    </tr>
                </tr>
            </thead>
            <tbody>
                <?php if($ref_users): ?>
                <?php $__currentLoopData = $ref_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ref_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td data-label="No"><div><span class="text-muted"><?php echo e($ref_user->user_name); ?></span></div></td>
               <td data-label="Typ"><div><?php echo e($ref_user->user_name); ?></div></td>
               <td data-label="Txnid"><div><?php echo e($ref_user->email); ?></div></td>
               <td data-label="Txnid"><div><?php echo e($ref_user->profile->phone); ?></div></td>
            
               <td data-label="Date">
                   <div><?php echo e($ref_user->created_at->format('j F,Y')); ?></div>
                </td>
            </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
              <tr>
                <td colspan="12">
                 <h4 class="text-center m-0 py-2">No Data Found</h4>
                </td>
               </tr>
              <?php endif; ?>    
            </tbody>
        </table>
    </div>
    <?php echo e($ref_users->links('pagination::bootstrap-4')); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('userDashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RBMS\resources\views\userDashboard\referrals.blade.php ENDPATH**/ ?>