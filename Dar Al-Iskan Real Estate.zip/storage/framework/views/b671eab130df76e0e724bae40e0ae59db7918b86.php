
<?php $__env->startSection('main'); ?>
<?php $__env->startPush('title'); ?>
<title>Referrals Commission</title>
<?php $__env->stopPush(); ?>
<div class="dashborad--content">
				<div class="breadcrumb-area">
    <h3 class="title">Refferal Commissions</h3>
    <ul class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a>
        </li>
        <li>Refferal Commissions</li>
    </ul>
</div>

<div class="dashboard--content-item">
    <div class="table-responsive table--mobile-lg">
        <table class="table bg--body">
            <thead>
                <tr>
                    <th>Referral Name</th>
                    <th>Type</th>
                    <th>Amount</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php if(isset($refTrans)): ?>
                <?php $__currentLoopData = $refTrans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refTran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td data-label="Date">
                          <div>
                            <?php echo e($refTran->user->user_name); ?>

                          </div>
                      </td>

                      <td data-label="Type">
                          <div>
                            <?php echo e($refTran->type); ?>

                          </div>
                      </td>

                      <td data-label="From">
                          <div>
                            $<?php echo e($refTran->amount); ?>

                          </div>
                        </td>
                        
                        <td data-label="Amount">
                            <div>
                              <?php echo e($refTran->created_at->format('j F,Y')); ?>

                            </div>
                        </td>
                    </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                 <?php endif; ?>              
          </tbody>
        </table>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('userDashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RBMS\resources\views\userDashboard\referralsCommission.blade.php ENDPATH**/ ?>