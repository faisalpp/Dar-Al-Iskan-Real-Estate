    <!-- Footer -->
    <!-- Footer -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/jquery-3.6.0.min.js', 'resources/js/bootstrap.min.js', 'resources/js/viewport.jquery.js', 'resources/js/odometer.min.js', 'resources/js/lightbox.min.js', 'resources/js/owl.min.js', 'resources/js/toastr.min.js', 'resources/js/notify.js', 'resources/js/main.js', 'resources/js/custom.js']); ?>
    <!-- Footer -->
    </body>

    </html>
<?php /**PATH C:\xampp\htdocs\RBMS\resources\views\layout\footer.blade.php ENDPATH**/ ?>