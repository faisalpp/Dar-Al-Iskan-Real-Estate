
<?php $__env->startSection('main'); ?>
<?php $__env->startPush('title'); ?>
<title>Transactions</title>
<?php $__env->stopPush(); ?>
<div class="dashborad--content">
				<div class="breadcrumb-area">
	<h3 class="title">Transactions</h3>
	<ul class="breadcrumb">
		<li>
			<a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a>
		</li>
  
		<li>Transactions</li>
	</ul>
</div>

<div class="dashboard--content-item">
	  <div class="table-responsive table--mobile-lg">
		  <table class="table bg--body">
			  <thead>
				  <tr>
					<th>No</th>
					<th>Type</th>
					<th>Sender</th>
					<th>Bank Name</th>
					<th>Amount</th>
					<th>Alert</th>
					<th>Status</th>
					<th>Date</th>
				  </tr>
			  </thead>
			  <tbody>
				<?php if(isset($all_transactions)): ?>
				<?php $__currentLoopData = $all_transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
				 <td data-label="No">
		  <div><span class="text-muted"><?php echo e($loop->index); ?></span></div>
		 </td>
				 <td data-label="Typ">
		  <div><?php echo e($all_transaction->type); ?></div>
				</td>
		 <td data-label="Txnid">
		     <?php if($all_transaction->type == 'INVEST'): ?>
		        <div>N/A</div>
		        <?php else: ?>
		        <div><?php echo e($all_transaction->wallet_address); ?></div>
		        <?php endif; ?>
				</td>
		 <td data-label="Txnid">
		   <?php if($all_transaction->type == 'INVEST' || $all_transaction->type == 'WITHDRAW'): ?>
		       <div>Main Wallet</div>
			<?php else: ?>
		       <div><?php echo e($all_transaction->bank_name); ?></div>
			<?php endif; ?>
				</td>
		 <td data-label="Amount">
		          <?php if($all_transaction->status == 'APPROVED' ): ?>
		           <div><p style="color:green">
		             <?php if($all_transaction->type == 'MEMBERSHIP FEE'): ?>
		               Rs.<?php echo e($all_transaction->amount); ?>

		             <?php elseif($all_transaction->type == 'INVEST'): ?>
		             <?php echo e($all_transaction->plan->coins); ?> Coins
		             <?php else: ?>
		               Rs.<?php echo e($all_transaction->amount); ?>

		             <?php endif; ?>
		           </p></div>
		          <?php endif; ?>
		          <?php if($all_transaction->status == 'REJECTED' ): ?>
		           <div><p style="color:red">
		             <?php if($all_transaction->type == 'MEMBERSHIP FEE'): ?>
		               Rs.<?php echo e($all_transaction->amount); ?>

		             <?php elseif($all_transaction->type == 'INVEST'): ?>
		              <?php echo e($all_transaction->plan->coins); ?> Coins
		             <?php else: ?>
		               Rs.<?php echo e($all_transaction->amount); ?>

		             <?php endif; ?>
		           </p></div>
		          <?php endif; ?>
		          <?php if($all_transaction->status == 'EXPIRED' ): ?>
		           <div><p style="color:black">
		             <?php if($all_transaction->type == 'MEMBERSHIP FEE'): ?>
		               Rs.<?php echo e($all_transaction->amount); ?>

		             <?php elseif($all_transaction->type == 'INVEST'): ?>
		              <?php echo e($all_transaction->plan->coins); ?> Coins
		             <?php else: ?>
		               Rs.<?php echo e($all_transaction->amount); ?>

		             <?php endif; ?>
		           </p></div>
		          <?php endif; ?>
		          <?php if($all_transaction->status == 'PENDING' ): ?>
		           <div><p style="color:orange">
		             <?php if($all_transaction->type == 'MEMBERSHIP FEE'): ?>
		               Rs.<?php echo e($all_transaction->amount); ?>

		             <?php elseif($all_transaction->type == 'INVEST'): ?>
		              <?php echo e($all_transaction->plan->coins); ?> Coins
		             <?php else: ?>
		               Rs.<?php echo e($all_transaction->amount); ?>

		             <?php endif; ?>
		           </p></div>
		          <?php endif; ?>
		          
		          
		  
				 </td>
		         <td data-label="Date">
				  <?php if($all_transaction->status === 'REJECTED'): ?>
				   
				  
				  <!-- Button trigger modal -->
				  <button type="button" style="border:none;background-color:#9A2441 !important;" class="btn btn-danger proof-button" data-bs-toggle="modal" data-bs-target="#invest-modal<?php echo e($loop->index); ?>">Message</button>
                <!-- Modal -->
				<div class="modal fade" id="invest-modal<?php echo e($loop->index); ?>">
            <div class="modal-dialog">
                <div class="modal-content">
                        <div class="modal-body p-4">
                            <h4 class="modal-title text-center plan-title">Rejection Message</h4>
                            
                            <div class="d-flex mt-2 p-4" style="border:2px solid blue;border-left:none;border-right:none;" >
                               <?php echo e($all_transaction->message); ?>

                            </div>
                         </div>
                </div>
            </div>
        </div>
		<?php else: ?>
		N/A 
		<?php endif; ?>
				 </td>
				 </td>
		 <td data-label="Date">
				  <div><?php echo e($all_transaction->status); ?></div>
				 </td>
		 <td data-label="Date">
				  <div><?php echo e($all_transaction->created_at->format('j F,Y')); ?></div>
				 </td>
		</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
				 <tr>
				   <td>No Record Found!</td> 
				 </tr>
				<?php endif; ?>	
			  </tbody>
		  </table>
		</div>
		<?php echo e($all_transactions->links('pagination::bootstrap-4')); ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('userDashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RBMS\resources\views\userDashboard\transactions.blade.php ENDPATH**/ ?>