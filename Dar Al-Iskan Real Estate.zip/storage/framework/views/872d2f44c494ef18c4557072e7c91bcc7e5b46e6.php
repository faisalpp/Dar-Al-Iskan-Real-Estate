    
    <?php $__env->startSection('main'); ?>
    <!-- Account Section -->
    <section class="accounts-section">
        <div class="accounts-inner">
            <div class="accounts-inner__wrapper bg--section">
                <div class="d-flex d-lg-none my-3 justify-content-center align-items-center w-100" > <img src="/logo.png" style="width:40%;border-radius:10px;border:1px solid orange" /></div>
                <div class="accounts-left">
                    <div class="accounts-left-content">
                        
                        <div class="section-header">
                            <h6 class="section-header__subtitle"></h6>
                            <h3 class="section-header__title"><?php echo app('translator')->get('Sign in to Dar Al-Iskan Real Estate'); ?></h3>
                            <p>
                            <?php echo app('translator')->get('Turn Your ideas into Reality'); ?>
                            </p>
                        </div>
                        <form class="row gy-4" id="loginfor" action="<?php echo e(url('/login')); ?>" method="post">
                            <div class="alert alert-success alert-dismissible fade show" style="display: none;">
                             <p class="m-0 text-success"></p>
                            </div>
                            <div class="alert alert-danger alert-dismissible fade show" style="display: none;" role="alert">
                             <p class="m-0 text-danger"></p>
                            </div>
                            <?php if(session()->has('success')): ?>
                            <span class="text--base text-center" >
                                 <?php echo e(session()->get('success')); ?>

                             </span>
                            <?php endif; ?>
                            <?php if(session()->has('error')): ?>
                            <span class="text--base text-center" >
                                 <?php echo e(session()->get('error')); ?>

                             </span>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <div class="col-sm-12">
                                <label for="email" class="form-label"><?php echo app('translator')->get('UserName Or Email'); ?></label>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input type="text" name="email" id="email" class="form-control">
                            </div>
                            <div class="col-sm-12">
                                <label for="password" class="form-label"><?php echo app('translator')->get('Your Password'); ?></label>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input type="password" name="password" id="password" class="form-control">
                            </div>
                            <div class="col-sm-12">
                                <button type="submit" class="cmn--btn"><?php echo app('translator')->get('Sign In'); ?> <div class="spinner-borde"></div></button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="accounts-right bg-dark" style="border: 2px solid #f3f9ff;;border-left:none">
                    <img src="<?php echo e(url('/side.png')); ?>" alt="images" style="border-radius:10px">
                    <div class="section-header text-center text-white mb-0">
                        <h6 class="section-header__subtitle"></h6>
                        <h3 class="section-header__title" style="font-size:25px"><?php echo app('translator')->get('Transform Your Real Estate Vision into Seamless Reality'); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dar Al-Iskan Real Estate\resources\views/login.blade.php ENDPATH**/ ?>