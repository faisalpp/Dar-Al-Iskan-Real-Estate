
<?php $__env->startSection('main'); ?>
<?php $__env->startPush('title'); ?>
<title>Withdraw History</title>
<?php $__env->stopPush(); ?>
<div class="dashborad--content">
				<div class="breadcrumb-area">
  <h3 class="title">Withdraw History</h3>
  <ul class="breadcrumb">
      <li>
        <a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a>
      </li>

      <li>Withdraw History</li>
  </ul>
</div>

<div class="dashboard--content-item">
    <div class="table-responsive table--mobile-lg">
        <table class="table bg--body">
            <thead>
                <tr>
                  <th>Transaction Id</th>
                  <th>Wallet Address</th>
                  <th>Amount</th>
                  <th>Status</th>
                  <th>Message</th>
                  <th>Date</th>
                </tr>
            </thead>
            <tbody>
              <?php if(isset($withdraws_history)): ?>
              <?php $__currentLoopData = $withdraws_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw_history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
               <td data-label="No"><div><span class="text-muted"><?php echo e($loop->index); ?></span></div></td>
               <td data-label="Txnid"><div><?php echo e($withdraw_history->wallet_address); ?></div></td>
               <td data-label="Date"><div>Rs.<?php echo e($withdraw_history->amount); ?></div></td>
               <td data-label="Date">
                <?php if($withdraw_history->status == "APPROVED"): ?>
                <div class="text-success" ><?php echo e($withdraw_history->status); ?></div>
                <?php elseif($withdraw_history->status == "REJECTED"): ?>
                <div class="text-alert" ><?php echo e($withdraw_history->status); ?></div>
                <?php else: ?>
                <div style="color:blue" ><?php echo e($withdraw_history->status); ?></div>
                <?php endif; ?> 
              </td>
               <td data-label="Date">
               <?php if($withdraw_history->message === ''): ?>
				   N/A 
				  <?php else: ?>
				  
				  <!-- Button trigger modal -->
				  <button type="button" style="border:none;background-color:#9A2441 !important;" class="btn btn-danger proof-button" data-bs-toggle="modal" data-bs-target="#invest-modal<?php echo e($loop->index); ?>">Message</button>
                <!-- Modal -->
				<div class="modal fade" id="invest-modal<?php echo e($loop->index); ?>">
            <div class="modal-dialog">
                <div class="modal-content">
                        <div class="modal-body p-4">
                            <h4 class="modal-title text-center plan-title">Rejection Message</h4>
                            
                            <div class="d-flex mt-2 p-4" style="border:2px solid blue;border-left:none;border-right:none;" >
                               <?php echo e($withdraw_history->message); ?>

                            </div>
                         </div>
                </div>
            </div>
        </div>
		<?php endif; ?>
               </td>
               <td data-label="Date"><div><?php echo e($withdraw_history->created_at->format('j F,Y')); ?></div></td>
             </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
              <tr>
                <td colspan="12">
                 <h4 class="text-center m-0 py-2">No Data Found</h4>
                </td>
               </tr>
              <?php endif; ?>    
            </tbody>
          </table>
          <?php echo e($withdraws_history->links('pagination::bootstrap-4')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('userDashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RBMS\resources\views\userDashboard\withdrawHistory.blade.php ENDPATH**/ ?>