

<?php $__env->startSection('main'); ?>
<?php $__env->startPush('title'); ?>
<title>Change Password</title>
<?php $__env->stopPush(); ?>
<div class="dashborad--content">
				<div class="breadcrumb-area">
    <h3 class="title">Change Password</h3>
    <ul class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a>
        </li>
        <li>Change Password</li>
    </ul>
</div>
<?php if(session()->has('success')): ?>
<div>
 <h5 class="text-success text-center mb-2" ><?php echo e(session()->get('success')); ?></h5>
</div>
<?php endif; ?>
<div class="dashboard--content-item">
    <div class="row justify-content-center">
        <div class="col-md-10 col-lg-8 col-xl-7 col-xxl-6">
            <div class="profile--card">
                <form id="request-form" action="<?php echo e(url('/admin/change-password')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row gy-4">
                        <div class="col-sm-12">
                            <label for="new-password" class="form-label">New Password</label>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="password" name="password" id="new-password" class="form-control"
                                placeholder="New Password" required>
                        </div>
                        <div class="col-sm-12">
                            <label for="confirm-password" class="form-label">Confirm Password</label>
                            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="password" name="password_confirmation" id="confirm-password" class="form-control"
                                placeholder="Confirm Password" required>
                        </div>
                        <div class="col-sm-12">
                            <div class="text-end">
                                <button type="submit" class="cmn--btn">Change Password</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminDashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RBMS\resources\views/adminDashboard/change-password.blade.php ENDPATH**/ ?>