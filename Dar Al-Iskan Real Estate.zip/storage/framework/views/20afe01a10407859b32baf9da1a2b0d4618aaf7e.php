
<?php $__env->startSection('main'); ?>
<?php $__env->startPush('title'); ?>
<title>Unlock Plans</title>
<?php $__env->stopPush(); ?>
<div class="dashborad--content">
				
<div class="breadcrumb-area">
  <h3 class="title">Extend Days</h3>
  <ul class="breadcrumb">
      <li>
        <a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a>
      </li>
      <li>Extend Days</li>
  </ul>
</div>
<?php if(session()->has('success')): ?>
<div>
 <h5 class="text-success text-center mb-2" ><?php echo e(session()->get('success')); ?></h5>
</div>
<?php endif; ?>
<div class="dashboard--content-item">
    <div id="request-form">
    <script>
    // Get references to the input and total fields
    
  // Add an onchange event listener to the input field
  function calculator() {

    
    const inputField = document.getElementById('days');
    const totalField = document.getElementById('total');
      // Get the value from the input field
  const inputValue = parseFloat(inputField.value);
    // Perform the calculation
    const result = inputValue * 100;

    // Update the total field with the calculated result
    totalField.value = result;
}
</script>
    <div class="profile--card">
      <div class="user--profile mb-5">
          

          <form class="row gy-4" enctype="multipart/form-data" action="<?php echo e(url('/user/extend-request')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="col-sm-6 col-xxl-4">
                  <label for="name" class="form-label">Check Payment Information</label>
                  <div class="col-sm-6">
                      <button type="button" style="background-color:orange !important" data-bs-toggle="modal" data-bs-target="#invest-modal33" class="cmn--btn">Payment Information</button>
                  </div>
              </div>

            <div class="col-sm-6 col-xxl-4">
                  <label for="name" class="form-label">Bank Name</label>
                  <select name="bank_name" class="form-control" >
                    <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($gateway->bank_name); ?>"><?php echo e($gateway->bank_name); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>         
              </div>
              <div class="col-sm-6 col-xxl-4">
                  <label for="email" class="form-label">Extending Days</label>
                  <input name="days" type="text" onchange="calculator()" id="days" class="form-control"
                      value="">
              </div>
              <div class="col-sm-6 col-xxl-4">
                  <label for="email" class="form-label">Total Price</label>
                  <input name="price" type="text" id="total" class="form-control"
                      value="" readonly>
              </div>

              <div class="col-sm-6 col-xxl-4">
                  <label for="name" class="form-label">Payment Proof</label>
                  <input type="file" id="name" name="proof" class="form-control" value="">
              </div>

              <div class="col-sm-6 col-xxl-4">
                  <label for="email" class="form-label">Sender Number</label>
                  <input name="wallet_address" type="text" id="email" class="form-control"
                      value="">
              </div>


              <div class="d-flex col-12">
                  <div class="col-sm-12 text-end">
                      <button type="submit" class="cmn--btn">Send Request</button>
                  </div>
              </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="invest-modal33">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form class="investForm" action="<?php echo e(url('/admin/create-gateway')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body ">
                            <h4 class="modal-title text-center plan-title">Payment&nbsp;Information</h4>
                            <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex flex-column mt-2 px-2 py-2" style="border:2px solid blue;border-left:none;border-right:none;" >
                              <div class="d-flex flex-lg-row flex-column align-items-center" >
                               <h5 class="mt-2 text-success" >Bank&nbsp;Name:</h5>
                               <h5 class="mt-2 mx-2" ><?php echo e($gateway->bank_name); ?></h5>  
                              </div>
                              <div class="d-flex flex-lg-row flex-column align-items-center" >
                                <h5 class="mt-2 text-success" >Receiver Name:</h5>  
                                <h5 class="mt-2 mx-2" ><?php echo e($gateway->acc_holder); ?></h5>  
                              </div>
                              <div class="d-flex flex-lg-row flex-column align-items-center" >
                                <h5 class="mt-2 text-success" >Account Number:</h5>  
                                <div class="input-group input--group">
                                    <input type="text" class="form-control form--control" readonly
                                        value="<?php echo e($gateway->acc_number); ?>" id="acc<?php echo e($loop->index); ?>">
                                    <input type="hidden" class="form-control form--control" readonly
                                        value="<?php echo e($gateway->acc_number); ?>" id="acc<?php echo e($loop->index); ?>">
                                    <button class="input-group-text px-3 btn--primary border-0" type="button" id="copyBoard" onclick="copy('<?php echo $loop->index ?>')">
                                        <i class="far fa-copy"></i>
                                    </button>
                                </div>
                                
                              </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('userDashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RBMS\resources\views\userDashboard\extendDays.blade.php ENDPATH**/ ?>