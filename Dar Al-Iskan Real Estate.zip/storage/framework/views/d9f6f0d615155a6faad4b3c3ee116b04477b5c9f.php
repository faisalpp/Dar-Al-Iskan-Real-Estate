<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo app('translator')->get('Clients'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"> -->
</head>
<script>
        // JavaScript to open print settings when the page loads
        window.onload = function() {
            window.print();
        };
    </script>
<body >
<?php if(count($clients) > 0): ?>
<div style="height:100vh;background-color:white" id="printarea" >
<table class="table table-responsive">
  <thead class="thead-dark">
    <tr>
	 <th scope="col" ><?php echo app('translator')->get('Full&nbsp;Name'); ?></th>
	 <th scope="col" ><?php echo app('translator')->get('Is Vip'); ?>?</th>
	 <th scope="col" ><?php echo app('translator')->get('Phone'); ?></th>
	 <th scope="col" ><?php echo app('translator')->get('Email'); ?></th>
	 <th scope="col" ><?php echo app('translator')->get('Address'); ?></th>
	 <th scope="col" ><?php echo app('translator')->get('Date'); ?></th>
	</tr>
  </thead>
  <tbody class="bg-white" >
    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td ><?php echo e($client->first_name); ?> <?php echo e($client->middle_name); ?> <?php echo e($client->last_name); ?></td>
      <td>
      <?php if($client->is_vip === 'yes'): ?>
      <?php echo app('translator')->get('Yes'); ?>
      <?php else: ?>
      <?php echo app('translator')->get('No'); ?>
      <?php endif; ?>
      </td>
      <td ><?php echo e($client->phone); ?></td>
      <td ><?php echo e($client->email); ?></td>
      <td ><?php echo e($client->address); ?></td>
      <td ><?php echo e(date_format($client->created_at,'d M Y')); ?></td>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
<?php else: ?>
 <div class="d-flex justify-content-center align-items-center w-100" style="height: calc(100vh - 500px)" >
   <h4><?php echo app('translator')->get('No Clients Found'); ?>!</h4>
 </div>
<?php endif; ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\Dar Al-Iskan Real Estate\resources\views/pdf/clientPdf.blade.php ENDPATH**/ ?>