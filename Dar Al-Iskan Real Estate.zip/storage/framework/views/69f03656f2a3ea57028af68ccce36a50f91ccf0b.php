
<?php $__env->startSection('main'); ?>
<?php $__env->startPush('title'); ?>
<title>Client Details</title>
<?php $__env->stopPush(); ?>

<script>
 $(document).ready(function () {
  // Intercept the form submission
  $('#client-form').submit(function () {
   // Show the loader
   $('#loader').removeClass('d-none');
   $('#form-btn-text').addClass('d-none');
  });
 });
</script>


<div class="dashborad--content">
				
<div class="breadcrumb-area">
  <h3 class="title">Client Details</h3>
  <ul class="breadcrumb">
      <li>
        <a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a>
      </li>
      <li>Client Details</li>
  </ul>
</div>
<?php if(session()->has('success')): ?>
<div>
 <h5 class="text-success text-center mb-2" ><?php echo e(session()->get('success')); ?></h5>
</div>
<?php endif; ?>

<div class="dashboard--content-item">
    <div id="request-form">
    <?php echo csrf_field(); ?>
    <div class="profile--card">
          <form id="client-form" class="row gy-4" action="<?php echo e(url('/admin/update-client')); ?>" method="post">
            <?php echo csrf_field(); ?>
              <div class="col-sm-6 col-lg-4 col-xxl-4">
                <label for="name" class="form-label">First Name</label>
                 <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="hidden" id="name" name="id" class="form-control" value="<?php echo e($client->id); ?>">
                <input type="text" id="name" name="first_name" class="form-control" value="<?php echo e($client->first_name); ?>">
              </div>
              <div class="col-sm-6 col-lg-4 col-xxl-4">
               <label for="email" class="form-label">Middle Name</label>
               <?php $__errorArgs = ['middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
               <input type="text" id="email" name="middle_name" class="form-control" value="<?php echo e($client->middle_name); ?>" >
              </div>
              <div class="col-sm-6 col-lg-4 col-xxl-4">
               <label for="email" class="form-label">last Name</label>
               <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
               <input type="text" id="email" name="last_name" class="form-control" value="<?php echo e($client->last_name); ?>" >
              </div>

              <div class="col-sm-6 col-xxl-4">
                  <label for="phone" class="form-label">Phone</label>
                  <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <div class="input-group">
                      <input type="text" name="phone" id="phone" class="form-control" value="<?php echo e($client->phone); ?>">
                  </div>
              </div>
              <div class="col-sm-6 col-xxl-4">
                  <label for="phone" class="form-label">Email</label>
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <div class="input-group">
                      <input type="text" name="email" id="phone" class="form-control" value="<?php echo e($client->email); ?>">
                  </div>
              </div>
              <div class="col-sm-6 col-xxl-4">
                  <label for="phone" class="form-label">Address</label>
                  <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <div class="input-group">
                      <input type="text" name="address" id="phone" class="form-control" value="<?php echo e($client->address); ?>">
                  </div>
              </div>

              <div class="col-sm-6 col-xxl-4">
                  <label for="phone" class="form-label">Is Client VIP?</label>
                  <?php $__errorArgs = ['is_vip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <label style="color:red;font-size:0.7rem" for="fullname-error" class="form-label text-sm "><?php echo e($message); ?></label>    
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <div class="input-group">
                  <select name="is_vip" class="form-control">
                    <?php if($client->is_vip === 'yes'): ?>
                    <option value="yes" >Yes</option>
                    <option value="no">No</option>
                    <?php else: ?>
                    <option value="no">No</option>
                    <option value="yes" >Yes</option>
                    <?php endif; ?>  
                </select>    
                  </div>
              </div>

              <div class="col-sm-12">
                  <div class="text-end">
                    <button type="submit" class="cmn--btn"><span id="form-btn-text" class="" >Update</span> <div id="loader" class="d-none">
                     <div class="spinner-border" role="status">
                             <span class="sr-only">Loading...</span>
                         </div>
                     </div>
                    </button>
                  </div>
              </div>
            </form>

           <div>
           <h4>Client Listings</h4>

           <?php if(count($listings) > 0): ?>
<table class="table bg--body">
			  <thead>
				  <tr>
					<th>Kroki No</th>
					<th>Title</th>
					<th>Land Type</th>
					<th>Land Size</th>
					<th>Date</th>
					<th>Actions</th>
				  </tr>
			  </thead>
			  <tbody>
        <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  <tr>
				 <td data-label="No"><div><span ><?php echo e($listing->serial_no); ?></span></div></td>
				 <td data-label="No"><div><span ><?php echo e($listing->title); ?></span></div></td>
				 <td data-label="No"><div><span ><?php echo e($listing->type); ?></span></div></td>
				 <td data-label="No"><div><span ><?php echo e($listing->size); ?></span></div></td>
				 <td data-label="No"><div><span ><?php echo e(date_format($listing->created_at,'d M Y')); ?></span></div></td>
				 <td data-label="No">
         <a title="View Listing" href="<?php echo e(url('/admin/view-listing')); ?>/<?php echo e($listing->id); ?>" style="border:none;font-weight:bold;background-color:orange;border-radius:100%;color:white;width:fit-content;padding:3px 9px 5px 9px" ><i class="fas fa-eye" style="font-size:14px" ></i></a>	
         <button title="Delete Listing" style="border:none;font-weight:bold;background-color:red;border-radius:100%;color:white;width:fit-content;padding:3px 9px 5px 9px" ><i class="fas fa-trash" style="font-size:14px" ></i></button>	
         </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php else: ?>
 <div class="d-flex justify-content-center align-items-center w-100" style="height: calc(100vh - 400px)" >
   <h4>Client Has No Listings!</h4>
 </div>
<?php endif; ?>

           </div>


        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminDashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dar Al-Iskan Real Estate\resources\views/adminDashboard/ViewClientDetail.blade.php ENDPATH**/ ?>