<?php $__env->startSection('main'); ?>
<?php $__env->startPush('title'); ?>
<title>Dashboard</title>
<?php $__env->stopPush(); ?>

<div class="dashborad--content">
				
<div class="breadcrumb-area">
  <h3 class="title">Dashboard</h3>
  <ul class="breadcrumb">
      <li>
          <a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a>
      </li>
      <li>Dashboard</li>
  </ul>
</div>
<?php if(session()->has('error')): ?>
<div>
    <h5 class="text-danger text-center mb-2" ><?php echo e(session()->get('error')); ?></h5>
</div>
<?php endif; ?>
<?php if(session()->has('success')): ?>
<div>
 <h5 class="text-success text-center mb-2" ><?php echo e(session()->get('success')); ?></h5>
</div>
<?php endif; ?>
<?php if(isset($membership)): ?>
<script>
// Set the date we're counting down to
var countDownDate = new Date("<?php echo $membership->expiration_date; ?>").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("demo").innerHTML = days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ";

  // If the count down is finished, write some text
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>


<?php endif; ?>

<?php if(isset($membership)): ?>
<div class="col-10 my-3 mx-auto" >
 <div class="d-flex flex-column col-12 px-3 pt-2 pb-3" style="background:white;border:1px solid #e5e5e5;;" > 
  <h4 class="text-center" style="color:#00A2FE" >MEMBERSHIP INFORMATION</h4>
  <div class="d-flex flex-lg-row flex-column col-12" >
   <div class="d-flex flex-lg-row flex-column col-lg-7 col-12" >
    <span style="color:black my-2" >Expirtation Status:</span> 
    <p class="mx-2 my-2" style="color:red" id="demo"></p>
   </div>
   <div class="d-flex justify-content-end mt-2" >
    <a href="<?php echo e(url('/user/extend-days')); ?>" ><button type="button" style="background-color:orange !important" data-bs-toggle="modal" data-bs-target="#invest-modal35" class="cmn--btn2">Extend Memberhsip (Rs.100 Per Day)</button></a>
   </div>
</div>
 </div>
</div>
<?php endif; ?>

<div class="dashboard--content-item">
      <div class="dashboard--wrapper">
        <div class="dashboard--width">
          <div class="dashboard-card h-100">
           <div class="dashboard-card__header">
            <div class="dashboard-card__header__icon">
	   	     <img src="<?php echo e(url('/c1.png')); ?>" alt="wallet">
            </div>
            <div class="dashboard-card__header__cont">
             <h6 class="name">Main Balance</h6>
             <div class="balance">Rs.<?php echo e($userAcc->balance); ?></div>
            </div>
           </div>
          </div>
       </div>

        <div class="dashboard--width">
            <div class="dashboard-card h-100">

                <div class="dashboard-card__header">
                    <div class="dashboard-card__header__icon">
                        <img src="<?php echo e(url('/c2.png')); ?>" alt="wallet">
                    </div>
                    <div class="dashboard-card__header__cont">
                        <h6 class="name">Total Coins</h6>
                        <div class="balance"><?php echo e($userAcc->coins); ?></div>
                    </div>
                </div>
            </div>
        </div>

		<div class="dashboard--width">
            <div class="dashboard-card h-100">

                <div class="dashboard-card__header">
                    <div class="dashboard-card__header__icon">
                        <img src="<?php echo e(url('/c4.png')); ?>" alt="wallet">
                    </div>
                    <div class="dashboard-card__header__cont">
                        <h6 class="name">Coins&nbsp;Invested</h6>
                        <div class="balance"><?php echo e($approved_deposit_amount); ?></div>
                    </div>
                </div>
            </div>
        </div>

      
        <div class="dashboard--width">
            <div class="dashboard-card h-100">

                <div class="dashboard-card__header">
                    <div class="dashboard-card__header__icon">
                        <img src="<?php echo e(url('/c5.png')); ?>" alt="wallet">
                    </div>
                    <div class="dashboard-card__header__cont">
                        <h6 class="name">Latest Withdraw</h6>
                        <?php if(isset($latest_withdraw)): ?>
                         <div class="balance">Rs.<?php echo e($latest_withdraw->amount); ?></div>
                        <?php else: ?>
                         <div class="balance">Rs.0</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

		<div class="dashboard--width">
            <div class="dashboard-card h-100">

                <div class="dashboard-card__header">
                    <div class="dashboard-card__header__icon">
                        <img src="<?php echo e(url('/c5.png')); ?>" alt="wallet">
                    </div>
                    <div class="dashboard-card__header__cont">
                        <h6 class="name">Pending Withdraw</h6>
                        <div class="balance">Rs.<?php echo e($pending_withdraw_amount); ?></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="dashboard--width">
            <div class="dashboard-card h-100">

                <div class="dashboard-card__header">
                    <div class="dashboard-card__header__icon">
                        <img src="<?php echo e(url('/c7.png')); ?>" alt="wallet">
                    </div>
                    <div class="dashboard-card__header__cont">
                        <h6 class="name">Last Transaction</h6>
                        <?php if(isset($last_deposit)): ?>
						 <?php if($last_deposit->type == 'INVEST'): ?>
                          <div class="balance"><?php echo e($last_deposit->plan->coins); ?> Coins</div>
                         <?php else: ?>
						  <div class="balance">Rs.<?php echo e($last_deposit->amount); ?></div>
                          <?php endif; ?>
                          <?php else: ?>
						  <div class="balance">Rs.0</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="dashboard--width">
            <div class="dashboard-card h-100">

                <div class="dashboard-card__header">
                    <div class="dashboard-card__header__icon">
                        <img src="<?php echo e(url('/c8.png')); ?>" alt="wallet">
                    </div>
                    <div class="dashboard-card__header__cont">
                        <h6 class="name">Total Referrals</h6>
						<div class="balance"><?php echo e($total_referrals); ?></div>
                    </div>
                </div>
            </div>
        </div>

		<div class="dashboard--width">
            <div class="dashboard-card h-100">

                <div class="dashboard-card__header">
                    <div class="dashboard-card__header__icon">
                        <img src="<?php echo e(url('/c8.png')); ?>" alt="wallet">
                    </div>
                    <div class="dashboard-card__header__cont">
                        <h6 class="name">Active Referrals</h6>
                        <div class="balance"><?php echo e($active_referrals); ?></div>
                    </div>
                </div>
            </div>
        </div>

		<div class="dashboard--width">
            <div class="dashboard-card h-100">

                <div class="dashboard-card__header">
                    <div class="dashboard-card__header__icon">
                        <img src="<?php echo e(url('/c6.png')); ?>" alt="wallet">
                    </div>
                    <div class="dashboard-card__header__cont">
                        <h6 class="name">Total Refferal Bonus</h6>
                        <?php if(isset($total_ref_bonus)): ?>
                         <div class="balance">Rs.<?php echo e($total_ref_bonus); ?></div>
                        <?php else: ?>
                         <div class="balance">Rs.0</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

		<div class="dashboard--width">
            <div class="dashboard-card h-100">

                <div class="dashboard-card__header">
                    <div class="dashboard-card__header__icon">
                        <img src="<?php echo e(url('/c6.png')); ?>" alt="wallet">
                    </div>
                    <div class="dashboard-card__header__cont">
                        <h6 class="name">Latest Refferal</h6>
                        <?php if(isset($latest_ref)): ?>
                        <div class="balance"><?php echo e($latest_ref->user_name); ?></div>
                        <?php else: ?>
                        <div class="balance">N/A</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

  </div>
</div>

<div class="dashboard--content-item">
  <div class="row gy-4">
      <div class="col-md-12">
          <div class="dashboard--content-item">
              <h5 class="dashboard-title">Referral URL</h5>
              <div class="dashboard-refer">
                  <div class="input-group input--group">
                      <input type="text" class="form-control form--control" readonly
                          value="<?php echo e(url('/register/ref')); ?>/<?php echo e(session()->get('user')['userName']); ?>" id="cronjobURL">
                      <button class="input-group-text px-3 btn--primary border-0" type="button" id="copyBoard" onclick="myFunction()">
                          <i class="far fa-copy"></i>
                      </button>
                  </div>
              </div>
          </div>
      </div>
  </div>
</div>

<div class="dashboard--content-item">
	  <div class="table-responsive table--mobile-lg">
		  <table class="table bg--body">
			  <thead>
				  <tr>
					<th>No</th>
					<th>Type</th>
					<th>Account Number</th>
					<th>Amount</th>
					<th>Status</th>
					<th>Date</th>
				  </tr>
			  </thead>
			  <tbody>
                <?php if(isset($all_transactions)): ?>
                <?php $__currentLoopData = $all_transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                 <td data-label="No">
				  <div><span class="text-muted"><?php echo e($loop->index); ?></span></div>
				 </td>
                 <td data-label="Typ">
				  <div><?php echo e($all_transaction->type); ?></div>
                </td>
				 <td data-label="Txnid">
				  <?php if($all_transaction->type == 'INVEST'): ?>
				  <div>N/A</div>
				  <?php else: ?>
				  <div><?php echo e($all_transaction->wallet_address); ?></div>
				  <?php endif; ?>
                </td>
				 <td data-label="Amount">
                  <?php if($all_transaction->type == 'INVEST' ): ?>
				  <div><p class="text-danger"><?php echo e($all_transaction->plan->coins); ?> Coins</p></div>
                  <?php else: ?>
                  <?php if($all_transaction->type == 'REFERRAL BONUS'): ?>
				   <div><p class="text-success">Rs.<?php echo e($all_transaction->amount); ?></p></div>
                  <?php else: ?>
				   <div><p class="text-danger">Rs.<?php echo e($all_transaction->amount); ?></p></div>
                  <?php endif; ?>
				  <?php endif; ?>
                 </td>
				 <td data-label="Date">
                  <div><?php echo e($all_transaction->status); ?></div>
                 </td>
				 <td data-label="Date">
                  <div><?php echo e($all_transaction->created_at->format('j F,Y')); ?></div>
                 </td>
				</tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                 <tr>
                   <td>No Record Found!</td> 
                 </tr>
                <?php endif; ?>
			  </tbody>
		  </table>
	  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('userDashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RBMS\resources\views\userDashboard\index.blade.php ENDPATH**/ ?>