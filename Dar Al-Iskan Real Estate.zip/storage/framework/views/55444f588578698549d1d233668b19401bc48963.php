
<?php $__env->startSection('main'); ?>
<?php $__env->startPush('title'); ?>
<title>Land Management</title>
<?php $__env->stopPush(); ?>
<div class="dashborad--content">
				<div class="breadcrumb-area">
  <h3 class="title"><?php echo app('translator')->get('Land Management'); ?></h3>
  <ul class="breadcrumb">
      <li>
        <a href="<?php echo e(url('/admin/dashboard')); ?>"><?php echo app('translator')->get('Dashboard'); ?></a>
      </li>
      <li><?php echo app('translator')->get('Land Management'); ?></li>
  </ul>
</div>

<script>
  function DeleteListing(id){
      // Show the loader
   $(`#loader-${id}`).removeClass('d-none');
   $(`#form-btn-text-${id}`).addClass('d-none');

   const formData = $(`#listing-form-${id}`).serialize();
  //  $(`#listing-form-${id}`).e.preventDefault()
// Make an Ajax POST request
$.ajax({
    type: 'POST',
    url: '<?php echo url("/admin/delete-listing"); ?>', // Replace with your actual endpoint
    data: formData,
    success: function(response) {
      toastr.success('Listing Successfully Deleted!');
      // location.reload(true); // 'true' forces a reload from the server
      $(`#loader-${id}`).addClass('d-none');
      $(`#form-btn-text-${id}`).removeClass('d-none');
    },
    error: function(error) {
      $(`#loader-${id}`).addClass('d-none');
      $(`#form-btn-text-${id}`).removeClass('d-none');
        // Handle the error response here
    }
});

  }
</script>

<?php if(session()->has('success')): ?>
    <script>
        // Display toastr notification with the success message
        toastr.success('<?php echo e(session('success')); ?>');
    </script>
<?php endif; ?>
<?php if(session()->has('error')): ?>
  <script>
   // Display toastr notification with the success message
   toastr.success('<?php echo e(session('error')); ?>');
  </script>
<?php endif; ?>
<div class="col-sm-12 mb-2">
<style>
                    .nav-btn1 {
                        background-color: #00A2FE;
                        color: white;
                        border: 2px solid #00A2FE;
                        width: fit-content;
                    }

                    .nav-btn1:hover {
                        background-color: transparent;
                        border: 2px solid #00A2FE;
                        color: #00A2FE;
                    }

                    .nav-btn2 {
                        border: 2px solid #00A2FE;
                        color: #00A2FE;
                    }

                    .nav-btn2:hover {
                        background-color: #00A2FE;
                        color: white;
                    }
                </style>

<div class="d-flex flex-column-reverse flex-lg-row justify-content-center align-items-center py-3">
  <div class="d-flex justify-content-start flex-row mt-2" >
   <a class="btn px-3 py-2 me-3 nav-btn1" style="border-radius:5px;font-size:0.87rem;font-weight:bold" href="<?php echo e(url('/admin/add-listing')); ?>">Add&nbsp;Listing</a> 
  </div>
 
  <!-- Search Bar -->
  <form action="" class="d-flex align-items-center justify-content-end flex-row w-100" >
  <h5 style="font-size:18px" ><?php echo app('translator')->get('Filters'); ?>:</h5> 
  <select name="filter" type="text" style="height:35px;width:fit-content;outline:none;margin-left:5px;margin-right:5px">
    <option value="serial_no" ><?php echo app('translator')->get('Kroki No'); ?></option>
    <option value="title" ><?php echo app('translator')->get('Title'); ?></option>
    <option value="size" ><?php echo app('translator')->get('Size'); ?></option>
    <option value="no_bedrooms" ><?php echo app('translator')->get('No Of Bedrooms'); ?></option>
    <option value="no_toilets" ><?php echo app('translator')->get('No Of Toilets'); ?></option>
    <option value="no_majlis" ><?php echo app('translator')->get('No Of Majlis'); ?></option>
    <option value="no_floors" ><?php echo app('translator')->get('No Of Floors'); ?></option>
    <option value="no_kitchens" ><?php echo app('translator')->get('No Of Kitchens'); ?></option>
   </select>
   <input type="text" name="search" class="w-25 w-sm-25" style="height:35px;outline:none" value="<?php echo e($search); ?>" />
   <button class="btn px-3 py-2" style="background-color:#D5924D;margin-left:10px;border-radius:5px;height:40px" href="<?php echo e(url('/admin/dashboard')); ?>"><i class="fas fa-search" style="color:white;font-size:14px"></i></button>
  </form>
  <button data-bs-toggle="modal" data-bs-target="#client-export" type="button" class="btn btn-success px-3 py-2" style="margin-left:10px;border-radius:5px;height:40px"><i class="fas fa-print" style="color:white;font-size:18px"></i></button>
  

</div>
<div style="overflow-x:scroll" >
 <?php if(count($listings) > 0): ?>
<table class="table bg--body">
			  <thead>
				  <tr>
					<th><?php echo app('translator')->get('Kroki No'); ?></th>
					<th><?php echo app('translator')->get('Title'); ?></th>
					<th><?php echo app('translator')->get('Land Type'); ?></th>
					<th><?php echo app('translator')->get('Land Size'); ?></th>
					<th><?php echo app('translator')->get('Date'); ?></th>
					<th><?php echo app('translator')->get('Actions'); ?></th>
				  </tr>
			  </thead>
			  <tbody>
        <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  <tr>
				 <td style="min-width:100px"><div><span ><?php echo e($listing->serial_no); ?></span></div></td>
				 <td style="min-width:100px"><div><span ><?php echo e($listing->title); ?></span></div></td>
				 <td style="min-width:100px"><div><span ><?php echo e($listing->type); ?></span></div></td>
				 <td style="min-width:100px"><div><span ><?php echo e($listing->size); ?></span></div></td>
				 <td style="min-width:100px"><div><span ><?php echo e(date_format($listing->created_at,'d M Y')); ?></span></div></td>
				 <td style="min-width:100px">
          <div class="d-flex justify-content-center" >
         <a title="View Listing" href="<?php echo e(url('/admin/view-listing')); ?>/<?php echo e($listing->id); ?>" style="border:none;font-weight:bold;background-color:orange;border-radius:100%;color:white;width:fit-content;padding:3px 8px 5px 8px" ><i class="fas fa-eye" style="font-size:14px" ></i></a>	
         <form id="listing-form-<?php echo e($listing->id); ?>" onSubmit="DeleteListing(<?php echo e($listing->id); ?>)" action="<?php echo e(url('/admin/delete-listing')); ?>" method="post" class="mx-2" >
              <?php echo csrf_field(); ?>  
              <input type="hidden" name="id" value="<?php echo e($listing->id); ?>" />
               <button title="Delete Client" style="border:none;font-weight:bold;background-color:red;border-radius:100%;color:white;width:fit-content;padding:3px 9px 5px 9px" >
                <i id="form-btn-text-<?php echo e($listing->id); ?>" class="fas fa-trash" style="font-size:14px" ></i>
                <div id="loader-<?php echo e($listing->id); ?>" class="d-none">
                <div class="spinner-border" style="width:14px;height:14px" role="status"><span class="sr-only">Loading...</span></div>
                </div>
              </button>	
              </form>	
                  </div>
         <!-- <button title="Delete Listing" style="border:none;font-weight:bold;background-color:red;border-radius:100%;color:white;width:fit-content;padding:3px 9px 5px 9px" ><i class="fas fa-trash" style="font-size:14px" ></i></button>	 -->
         </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo e($listings->links()); ?>

                  </div>
<?php else: ?>
 <div class="d-flex justify-content-center align-items-center w-100" style="height: calc(100vh - 400px)" >
   <h4><?php echo app('translator')->get('No Listing Found'); ?>!</h4>
 </div>
<?php endif; ?>
</div>

<script>
  $(document).ready(function(){
    $('#print_options').on('change', function(){
      const option = $('#print_options').val();
      console.log(option)
      if(option === 'all-time'){
        $('#date_start').css('display','none')
        $('#date_end').css('display','none')
      }else{
        $('#date_start').css('display','flex')
        $('#date_end').css('display','flex')
      }
    });
  });
</script>

<script>
$(document).ready(function(){
 $('#pdf-form').on('submit',function(){
  $('#loader-download').removeClass('d-none');
   $('#download-txt').addClass('d-none');  
 });
});
</script>

 <!-- Invest Modal -->
<div class="modal fade" id="client-export">
 <div class="modal-dialog">
  <div class="modal-content">
   <form action="<?php echo e(url('/admin/export-listings-pdf')); ?>" method="POST" id="pdf-form" style="gap:10px" class="d-flex me-5 flex-column align-items-center justify-content-center my-2 mx-4" >
   <?php echo csrf_field(); ?>
   <div class="d-flex flex-column align-items-center" style="width:50%" >
    <h4 style="font-size:16px;align-self:start" ><?php echo app('translator')->get('Filter'); ?></h4>
   <select id="print_options" name="print-options" class="form-control" style="width:100%" >
    <option value="all-time"><?php echo app('translator')->get('All Time'); ?></option>
    <option value="by-date" ><?php echo app('translator')->get('By Date'); ?></option>
   </select>
</div>
   <div id="date_start" class="flex-column align-items-center" style="display:none;width:50%" >
    <h4 style="font-size:16px;align-self:start" ><?php echo app('translator')->get('Start Date'); ?></h4>
    <input type="date" name="date_start" class="form-control" style="width:100%" />
   </div>
   <div id="date_end" class="flex-column align-items-center" style="display:none;width:50%" >
    <h4 style="font-size:16px;align-self:start" ><?php echo app('translator')->get('End Date'); ?></h4>
    <input type="date" name="date_end" class="form-control" style="width:100%" />    
   </div>
   <div class="d-flex me-5 w-100 justify-content-center" >
    <button class="btn px-3 py-2" style="color:white;background-color:#D5924D;margin-left:10px;border-radius:5px;height:40px">
     <span id="download-txt" ><?php echo app('translator')->get('Download'); ?></span>
     <div id="loader-download" class="d-none">
      <div class="spinner-border" style="width:14px;height:14px" role="status"><span class="sr-only">Loading...</span></div>
     </div>
    </button>
   </div> 
  </form> 
 </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminDashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dar Al-Iskan Real Estate\resources\views/adminDashboard/ManageListing.blade.php ENDPATH**/ ?>