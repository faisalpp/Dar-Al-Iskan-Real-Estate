<?php $__env->startSection('main'); ?>
<?php $__env->startPush('title'); ?>
<title><?php echo app('translator')->get('Dashboard'); ?></title>
<?php $__env->stopPush(); ?>
<div class="dashborad--content">
				
<div class="breadcrumb-area">
  <h3 class="title"><?php echo app('translator')->get('Dashboard'); ?></h3>
  <ul class="breadcrumb">
      <li>
          <a href="<?php echo e(url('/user/dashboard')); ?>"><?php echo app('translator')->get('Dashboard'); ?></a>
      </li>
      <li><?php echo app('translator')->get('Dashboard'); ?></li>
  </ul>
</div>

<script>
  $(document).ready(function() {
    $('#language-switcher').on('change',function(){
      $('#language-switcher-form').submit()
    })
  })
</script>

<form id="language-switcher-form" action="<?php echo e(url('/change-language')); ?>" method="POST" class="d-flex w-100 justify-content-end mb-3" >
<?php echo csrf_field(); ?>  
<select id="language-switcher" name="language" class="form-control" style="width:fit-content" >
    <?php if(app()->getLocale() === 'ar'): ?>
    <option value="ar" ><?php echo app('translator')->get('Arabic'); ?></option>
    <option value="en" ><?php echo app('translator')->get('English'); ?></option>
     <?php else: ?>
     <option value="en" ><?php echo app('translator')->get('English'); ?></option>
     <option value="ar" ><?php echo app('translator')->get('Arabic'); ?></option>
    <?php endif; ?>
  </select>
</form>

<div class="dashboard--content-item">
  <div class="dashboard--wrapper">

        <div class="dashboard--width">
         <div class="dashboard-card h-100">
          <div class="dashboard-card__header">
           <div class="dashboard-card__header__icon">
			<i class="fas fa-crown" ></i>
           </div>
           <div class="dashboard-card__header__cont">
            <h6 class="name"><?php echo app('translator')->get('Vip Clients'); ?></h6>
            <div class="balance" style="font-weight:bold"><?php echo e($total_vip_clients); ?></div>
           </div>
          </div>
         </div>
        </div>

		<div class="dashboard--width">
         <div class="dashboard-card h-100">
          <div class="dashboard-card__header">
           <div class="dashboard-card__header__icon">
			<i class="fas fa-user" ></i>
           </div>
           <div class="dashboard-card__header__cont">
            <h6 class="name"><?php echo app('translator')->get('General Clients'); ?></h6>
            <div class="balance" style="font-weight:bold"><?php echo e($total_org_clients); ?></div>
           </div>
          </div>
         </div>
        </div>
	
		<div class="dashboard--width">
         <div class="dashboard-card h-100">
          <div class="dashboard-card__header">
           <div class="dashboard-card__header__icon">
			<i class="fas fa-map" ></i>
           </div>
           <div class="dashboard-card__header__cont">
            <h6 class="name"><?php echo app('translator')->get('Listing On Sell'); ?></h6>
            <div class="balance" style="font-weight:bold"><?php echo e($total_onsell_listings); ?></div>
           </div>
          </div>
         </div>
        </div>

		<div class="dashboard--width">
         <div class="dashboard-card h-100">
          <div class="dashboard-card__header">
           <div class="dashboard-card__header__icon">
			<i class="fas fa-map" ></i>
           </div>
           <div class="dashboard-card__header__cont">
            <h6 class="name"><?php echo app('translator')->get('Listing Sold'); ?></h6>
            <div class="balance" style="font-weight:bold"><?php echo e($total_sold_listings); ?></div>
           </div>
          </div>
         </div>
        </div>

  </div> 
</div> 

<div class="my-5" >
 <h4 style="font-weight:bold"><?php echo app('translator')->get('Latest Listings'); ?></h4>
</div>

<?php if(count($latest_listings) > 0): ?>
<div style="overflow-x:scroll">
<table class="table table-responsive">
  <thead class="thead-dark">
    <tr>
		 <th scope="col" ><?php echo app('translator')->get('Kroki No'); ?></th>
		 <th scope="col" ><?php echo app('translator')->get('Title'); ?></th>
		 <th scope="col" ><?php echo app('translator')->get('Land Type'); ?></th>
		 <th scope="col" ><?php echo app('translator')->get('Land Size'); ?></th>
		 <th scope="col" ><?php echo app('translator')->get('Date'); ?></th>
		 <th scope="col" ><?php echo app('translator')->get('Actions'); ?></th>
		</tr>
  </thead>
  <tbody class="bg-white" >
    <?php $__currentLoopData = $latest_listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td style="min-width:100px" ><?php echo e($listing->serial_no); ?></td>
		  <td style="min-width:100px" ><?php echo e($listing->title); ?></td>
      <?php if($listing->type === 'Apartment'): ?>
		  <td style="min-width:100px" ><?php echo app('translator')->get('Apartment'); ?></td>
		  <?php elseif($listing->type === 'Land'): ?>
		  <td style="min-width:100px" ><?php echo app('translator')->get('Land'); ?></td>
      <?php else: ?>
		  <td style="min-width:100px" ><?php echo app('translator')->get('Villa'); ?></td>
      <?php endif; ?>

      <td style="min-width:100px" ><?php echo e($listing->size); ?></td>
		  <td style="min-width:100px" ><?php echo e(date_format($listing->created_at,'d M Y')); ?></td>
      <td>
          <div class="d-flex justify-content-center" >
         <a title="View Listing" href="<?php echo e(url('/admin/view-listing')); ?>/<?php echo e($listing->id); ?>" style="border:none;font-weight:bold;background-color:orange;border-radius:100%;color:white;width:fit-content;padding:3px 8px 5px 8px" ><i class="fas fa-eye" style="font-size:14px" ></i></a>	
         <form id="listing-form-<?php echo e($listing->id); ?>" onSubmit="DeleteListing(<?php echo e($listing->id); ?>)" action="<?php echo e(url('/admin/delete-listing')); ?>" method="post" class="mx-2" >
              <?php echo csrf_field(); ?>  
              <input type="hidden" name="id" value="<?php echo e($listing->id); ?>" />
               <button title="Delete Client" style="border:none;font-weight:bold;background-color:red;border-radius:100%;color:white;width:fit-content;padding:3px 9px 5px 9px" >
                <i id="form-btn-text-<?php echo e($listing->id); ?>" class="fas fa-trash" style="font-size:14px" ></i>
                <div id="loader-<?php echo e($listing->id); ?>" class="d-none">
                <div class="spinner-border" style="width:14px;height:14px" role="status"><span class="sr-only">Loading...</span></div>
                </div>
              </button>	
              </form>	
</div>
         </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
<?php else: ?>
 <div class="d-flex justify-content-center align-items-center w-100" style="height: calc(100vh - 600px)" >
   <h4><?php echo app('translator')->get('No Listings Found!'); ?></h4>
 </div>
<?php endif; ?>


<div>
 <h4 style="font-weight:bold"><?php echo app('translator')->get('Latest Clients'); ?></h4>
</div>


<?php if(count($latest_clients) > 0): ?>
<div style="overflow-x:scroll">
<table class="table table-responsive" style="overflow-x:scroll">
  <thead class="thead-dark">
    <tr>
      <th scope="col"><?php echo app('translator')->get('Client Name'); ?></th>
			<th scope="col"><?php echo app('translator')->get('Type'); ?></th>
			<th scope="col"><?php echo app('translator')->get('Email'); ?></th>
			<th scope="col"><?php echo app('translator')->get('Phone'); ?></th>
			<th scope="col"><?php echo app('translator')->get('Date'); ?></th>
			<th scope="col"><?php echo app('translator')->get('Listings'); ?></th>
    </tr>
  </thead>
  <tbody class="bg-white" >
    <?php $__currentLoopData = $latest_clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td style="min-width:200px" ><?php echo e($client->first_name); ?>&nbsp;<?php echo e($client->middle_name); ?>&nbsp;<?php echo e($client->last_name); ?></td>
      <td style="min-width:50px" >
      <?php if($client->is_vip === 'yes'): ?>
       <div title="VIP" style="font-weight:bold;background-color:#800080;border-radius:100%;color:white;width:fit-content;padding:3px 8px 5px 8px" ><i class="fas fa-crown" style="font-size:12px" ></i></div>
      <?php else: ?>
      <div title="Normal" style="font-weight:bold;background-color:orange;border-radius:100%;color:white;width:fit-content;padding:3px 9px 5px 9px" ><i class="fas fa-user" style="font-size:14px" ></i></div>	
      <?php endif; ?>
      </td>
      <td style="min-width:100px" ><?php echo e($client->email); ?></td>
      <td style="min-width:150px" ><?php echo e($client->phone); ?></td>
      <td style="min-width:100px" ><?php echo e(date_format($client->created_at,"d M Y")); ?></td>
      <td>
      <div class="d-flex justify-content-center" >
							<a title="View Client" href="<?php echo e(url('/admin/view-client')); ?>/<?php echo e($client->id); ?>" style="border:none;font-weight:bold;background-color:orange;border-radius:100%;color:white;width:fit-content;padding:3px 9px 5px 9px" ><i class="fas fa-eye" style="font-size:14px" ></i></a>	
              <form id="client-form-<?php echo e($client->id); ?>" onSubmit="DeleteClient(<?php echo e($client->id); ?>)" action="<?php echo e(url('/admin/delete-client')); ?>" method="post" class="mx-2" >
              <?php echo csrf_field(); ?>  
              <input type="hidden" name="id" value="<?php echo e($client->id); ?>" />
               <button title="Delete Client" style="border:none;font-weight:bold;background-color:red;border-radius:100%;color:white;width:fit-content;padding:3px 9px 5px 9px" >
                <i id="form-btn-text-<?php echo e($client->id); ?>" class="fas fa-trash" style="font-size:14px" ></i>
                <div id="loader-<?php echo e($client->id); ?>" class="d-none">
                <div class="spinner-border" style="width:14px;height:14px" role="status"><span class="sr-only">Loading...</span></div>
                </div>
              
              </button>	
              </form>	
             </div>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
<?php else: ?>
 <div class="d-flex justify-content-center align-items-center w-100" style="height: calc(100vh - 600px)" >
   <h4><?php echo app('translator')->get('No Clients Found!'); ?></h4>
 </div>
<?php endif; ?>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminDashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dar Al-Iskan Real Estate\resources\views/adminDashboard/index.blade.php ENDPATH**/ ?>