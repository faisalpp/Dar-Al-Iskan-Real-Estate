
<?php $__env->startSection('main'); ?>
<?php $__env->startPush('title'); ?>
<title>Invest History</title>
<?php $__env->stopPush(); ?>
<div class="dashborad--content">
				<div class="breadcrumb-area">
    <h3 class="title">Invest History</h3>
    <ul class="breadcrumb">
        <li>
          <a href="<?php echo e(url('/user/dashboard')); ?>">Dashboard</a>
        </li>
        <li>Invest History</li>
    </ul>
</div>

<div class="dashboard--content-item">
    <!-- <h5 class="dashboard-title">Invests</h5> -->
    <div class="table-responsive table--mobile-lg">
        <table class="table bg--body">
            <thead>
                <tr>
                    <th>Transaction Id</th>
                    <th>Method</th>
                    <th>Package Name</th>
                    <th>Package Amount</th>
                    <th>duration</th>
                    <th>Status</th>
                    <th>Purchase Date</th>
                </tr>
            </thead>
            <tbody>
              <?php if(isset($all_transactions)): ?>
              <?php $__currentLoopData = $all_transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
               <td data-label="No">
        <div><span class="text-muted"><?php echo e($loop->index); ?></span></div>
       </td>
               <td data-label="Typ">
        <div><?php echo e($all_transaction->type); ?></div>
              </td>
       <td data-label="Txnid">
        <div><?php echo e($all_transaction->plan->title); ?></div>
              </td>

       <td data-label="Date">
                <div><?php echo e($all_transaction->plan->coins); ?> Coins</div>
               </td>
       <td data-label="Date">
                <div><?php echo e($all_transaction->plan->duration); ?> Days</div>
               </td>
       <td data-label="Date">
                <div><?php echo e($all_transaction->status); ?></div>
               </td>
       <td data-label="Date">
                <div><?php echo e($all_transaction->created_at->format('j F,Y')); ?></div>
               </td>
      </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
              <tr>
                <td colspan="12">
                 <h4 class="text-center m-0 py-2">No Data Found</h4>
                </td>
               </tr>
              <?php endif; ?>    
            </tbody>
        </table>
    </div>
    <?php echo e($all_transactions->links('pagination::bootstrap-4')); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('userDashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RBMS\resources\views\userDashboard\investHistory.blade.php ENDPATH**/ ?>