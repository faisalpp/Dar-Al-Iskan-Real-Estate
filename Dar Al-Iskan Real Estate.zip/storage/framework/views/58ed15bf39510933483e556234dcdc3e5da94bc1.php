
<?php $__env->startSection('main'); ?>
<?php $__env->startPush('title'); ?>
<title>Land Management</title>
<?php $__env->stopPush(); ?>
<div class="dashborad--content">
				<div class="breadcrumb-area">
  <h3 class="title">Land Management</h3>
  <ul class="breadcrumb">
      <li>
        <a href="<?php echo e(url('/admin/dashboard')); ?>">Dashboard</a>
      </li>

      <li>Land Management</li>
  </ul>
</div>
<?php if(session()->has('success')): ?>
<div>
 <h5 class="text-success text-center mb-2" ><?php echo e(session()->get('success')); ?></h5>
</div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
<div>
 <h5 class="text-danger text-center mb-2" ><?php echo e(session()->get('error')); ?></h5>
</div>
<?php endif; ?>
<div class="col-sm-12 mb-2">
<style>
                    .nav-btn1 {
                        background-color: #00A2FE;
                        color: white;
                        border: 2px solid #00A2FE;
                        width: fit-content;
                    }

                    .nav-btn1:hover {
                        background-color: transparent;
                        border: 2px solid #00A2FE;
                        color: #00A2FE;
                    }

                    .nav-btn2 {
                        border: 2px solid #00A2FE;
                        color: #00A2FE;
                    }

                    .nav-btn2:hover {
                        background-color: #00A2FE;
                        color: white;
                    }
                </style>

<div class="d-flex align-items-center py-3">
  <div class="d-flex justify-content-start flex-row w-100" >
  <a class="btn px-3 py-2 me-3 nav-btn1" style="border-radius:5px;font-size:14px;font-weight:bold" href="<?php echo e(url('/admin/dashboard')); ?>">Add Listing</a>
</div>
 
  <!-- Search Bar -->
  <div class="d-flex align-items-center justify-content-end flex-row w-100" >
   <input type="text" style="height:35px;width:50%;outline:none" />
   <a class="btn px-3 py-2 bg-success" style="margin-left:10px;border-radius:5px;height:40px" href="<?php echo e(url('/admin/dashboard')); ?>"><i class="fas fa-search" style="color:white;font-size:14px"></i></a>
 </div>
  

</div>
 
<table class="table bg--body">
			  <thead>
				  <tr>
					<th>Client Name</th>
					<th>Type</th>
					<th>Location</th>
					<th>Amount</th>
					<th>Status</th>
					<th>Date</th>
				  </tr>
			  </thead>
			  <tbody>

			  <tr>
						<td data-label="No">
							<div>
							<span style="font-weight:bold" >M.Faisal</span>
							</div>
						</td>
        </tr>
</table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminDashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RBMS\resources\views\adminDashboard\ManageListing.blade.php ENDPATH**/ ?>