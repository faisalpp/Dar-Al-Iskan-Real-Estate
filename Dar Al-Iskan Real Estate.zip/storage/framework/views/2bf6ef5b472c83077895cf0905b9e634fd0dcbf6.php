
<?php $__env->startSection('main'); ?>
<?php $__env->startPush('title'); ?>
<title><?php echo app('translator')->get('User Management'); ?></title>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopPush(); ?>

<!-- unBan Form Function Start -->
<script>
  function UnBanClient(id){
      // Show the loader
   $(`#loader-unban-${id}`).removeClass('d-none');
   $(`#form-unban-btn-text-${id}`).addClass('d-none');

   const formData = new FormData();
   formData.append('id',id);

// Make an Ajax POST request
$.ajax({
    type: 'POST',
    url: '<?php echo url("/admin/unban-user"); ?>', // Replace with your actual endpoint
    data: formData,
    contentType: false,
    processData: false,
    headers: {
     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    success: function(response) {
      window.location.reload()
      toastr.success('User Successfully UnBanned!');
      // location.reload(true); // 'true' forces a reload from the server
      $(`#loader-unban-${id}`).addClass('d-none');
      $(`#form-unban-btn-text-${id}`).removeClass('d-none');
    },
    error: function(error) {
      toastr.error('Internal Server Error!');
      $(`#loader-ban-${id}`).addClass('d-none');
      $(`#form-unban-btn-text-${id}`).removeClass('d-none');
        // Handle the error response here
    }
});

  }
</script>

<!-- unBan Form Function End -->
<!-- Ban Form Function Start -->
<script>
  function BanClient(id){
      // Show the loader
   $(`#loader-ban-${id}`).removeClass('d-none');
   $(`#form-ban-btn-text-${id}`).addClass('d-none');

   const formData = new FormData();
   formData.append('id',id);

// Make an Ajax POST request
$.ajax({
    type: 'POST',
    url: '<?php echo url("/admin/ban-user"); ?>', // Replace with your actual endpoint
    data: formData,
    contentType: false,
    processData: false,
    headers: {
     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    success: function(response) {
      window.location.reload()
      toastr.success('User Successfully Banned!');
      // location.reload(true); // 'true' forces a reload from the server
      $(`#loader-ban-${id}`).addClass('d-none');
      $(`#form-ban-btn-text-${id}`).removeClass('d-none');
    },
    error: function(error) {
      toastr.error('Internal Server Error!');
      $(`#loader-ban-${id}`).addClass('d-none');
      $(`#form-ban-btn-text-${id}`).removeClass('d-none');
        // Handle the error response here
    }
});

  }
</script>

<!-- Ban Form Function End -->
<!-- Delete Form Function Start -->
<script>
  function DeleteClient(id){
      // Show the loader
   $(`#loader-${id}`).removeClass('d-none');
   $(`#form-btn-text-${id}`).addClass('d-none');

   const formData = new FormData();
   formData.append('id',id);

// Make an Ajax POST request
$.ajax({
    type: 'POST',
    url: '<?php echo url("/admin/delete-user"); ?>', // Replace with your actual endpoint
    data: formData,
    contentType: false,
    processData: false,
    headers: {
     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
    success: function(response) {
      console.log(response)
      toastr.success('User Successfully Deleted!');
      // location.reload(true); // 'true' forces a reload from the server
      $(`#loader-${id}`).addClass('d-none');
      $(`#form-btn-text-${id}`).removeClass('d-none');
    },
    error: function(error) {
      toastr.error('Internal Server Error!');
      $(`#loader-${id}`).addClass('d-none');
      $(`#form-btn-text-${id}`).removeClass('d-none');
        // Handle the error response here
    }
});

  }
</script>

<!-- Delete Form Function End -->



<div class="dashborad--content">
				<div class="breadcrumb-area">
  <h3 class="title"><?php echo app('translator')->get('User Management'); ?></h3>
  <ul class="breadcrumb">
      <li>
        <a href="<?php echo e(url('/admin/dashboard')); ?>"><?php echo app('translator')->get('Dashboard'); ?></a>
      </li>

      <li><?php echo app('translator')->get('User Management'); ?></li>
  </ul>
</div>

<?php if(session()->has('success')): ?>
    <script>
        // Display toastr notification with the success message
        toastr.success('<?php echo e(session('success')); ?>');
    </script>
<?php endif; ?>
<?php if(session()->has('error')): ?>
  <script>
   // Display toastr notification with the success message
   toastr.success('<?php echo e(session('error')); ?>');
  </script>
<?php endif; ?>

<div class="col-sm-12 mb-2">
<style>
.nav-btn1 {
    background-color: #00A2FE;
    color: white;
    border: 2px solid #00A2FE;
    width: fit-content;
}
.nav-btn1:hover {
    background-color: transparent;
    border: 2px solid #00A2FE;
    color: #00A2FE;
}
.nav-btn2 {
    border: 2px solid #00A2FE;
    color: #00A2FE;
}
.nav-btn2:hover {
    background-color: #00A2FE;
    color: white;
}
</style>

<div class="d-flex flex-column-reverse flex-lg-row justify-content-center align-items-center py-3">
  <div class="d-flex justify-content-start flex-row mt-2" >
  <a class="btn px-3 py-2 me-3 nav-btn1" style="border-radius:5px;font-size:0.87rem;font-weight:bold;min-width:100px" href="<?php echo e(url('/admin/add-user')); ?>"><?php echo app('translator')->get('Add User'); ?></a>
</div>
 
  <!-- Search Bar -->
  <form action="" class="d-flex align-items-center justify-content-end flex-row w-100" >
  <h5 style="font-size:18px" ><?php echo app('translator')->get('Filters'); ?>:</h5> 
  <select name="filter" type="text" style="height:35px;width:fit-content;outline:none;margin-left:5px;margin-right:5px">
    <option value="all" ><?php echo app('translator')->get('All users'); ?></option>
    <option value="user_name" ><?php echo app('translator')->get('UserName'); ?></option>
    <option value="email" ><?php echo app('translator')->get('Email'); ?></option>
    <option value="phone" ><?php echo app('translator')->get('Phone'); ?></option>
   </select>
   <input type="text" name="search" style="height:35px;width:20%;outline:none" value="<?php echo e($search); ?>" />
   <button class="btn px-3 py-2" style="background-color:#D5924D;margin-left:10px;border-radius:5px;height:40px" href="<?php echo e(url('/admin/dashboard')); ?>"><i class="fas fa-search" style="color:white;font-size:14px"></i></button>
  </form>
  <!-- <button data-bs-toggle="modal" data-bs-target="#client-export" type="button" class="btn btn-success px-3 py-2" style="margin-left:10px;border-radius:5px;height:40px" href="<?php echo e(url('/admin/dashboard')); ?>"><i class="fas fa-print" style="color:white;font-size:18px"></i></button> -->
</div>

 <?php if(count($users) > 0): ?>
 <div style="overflow-x:scroll" >
<table class="table bg--body">
			  <thead>
				  <tr>
					<th><?php echo app('translator')->get('User Name'); ?></th>
					<th><?php echo app('translator')->get('Email'); ?></th>
					<th><?php echo app('translator')->get('Phone'); ?></th>
					<th><?php echo app('translator')->get('Date'); ?></th>
					<th><?php echo app('translator')->get('Status'); ?></th>
					<th><?php echo app('translator')->get('Actions'); ?></th>
				  </tr>
			  </thead>
			  <tbody>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  <tr>
						<td style="min-width:100px" ><?php echo e($user->user_name); ?></td>
            <td style="min-width:100px"><?php echo e($user->email); ?></td>
            <td style="min-width:130px"><?php echo e($user->phone); ?></td>
            <td style="min-width:100px">Dec 28 2024</td>
            <td style="min-width:100px">
            <?php if($user->status === '1'): ?>
             Working
             <?php else: ?>
             Banned
             <?php endif; ?>
            </td>
            <td style="min-width:100px">
            <div class="d-flex justify-content-center" >
              <div id="client-form-<?php echo e($user->id); ?>" class="mx-2" >  
               <button type="button" onclick="DeleteClient(<?php echo e($user->id); ?>)" title="Delete User" style="border:none;font-weight:bold;background-color:red;border-radius:100%;color:white;width:fit-content;padding:3px 9px 5px 9px" >
                <i id="form-btn-text-<?php echo e($user->id); ?>" class="fas fa-trash" style="font-size:14px" ></i>
                <div id="loader-<?php echo e($user->id); ?>" class="d-none">
                <div class="spinner-border" style="width:14px;height:14px" role="status"><span class="sr-only">Loading...</span></div>
                </div>
              </button>	
             </div>	
             <?php if($user->status === '1'): ?>
              <div id="client-ban-form-<?php echo e($user->id); ?>" class="mx-2" >  
               <button type="button" onclick="BanClient(<?php echo e($user->id); ?>)" title="Ban User" style="border:none;font-weight:bold;background-color:orange;border-radius:100%;color:white;width:fit-content;padding:5px 7px 3px 7px" >
                <i id="form-ban-btn-text-<?php echo e($user->id); ?>" class="fas fa-ban" style="font-size:18px" ></i>
                <div id="loader-ban-<?php echo e($user->id); ?>" class="d-none">
                <div class="spinner-border" style="width:14px;height:14px" role="status"><span class="sr-only">Loading...</span></div>
                </div>
              </button>	
             </div>	
             <?php else: ?>
             <div id="client-unban-form-<?php echo e($user->id); ?>" class="mx-2" >  
              <button type="button" onclick="UnBanClient(<?php echo e($user->id); ?>)" title="UnBan User" style="border:none;font-weight:bold;background-color:orange;border-radius:100%;color:white;width:fit-content;padding:5px 7px 3px 7px" >
               <i id="form-unban-btn-text-<?php echo e($user->id); ?>" class="fas fa-redo" style="font-size:16px" ></i>
               <div id="loader-unban-<?php echo e($user->id); ?>" class="d-none">
               <div class="spinner-border" style="width:14px;height:14px" role="status"><span class="sr-only">Loading...</span></div>
               </div>
             </button>	
            </div>	
             <?php endif; ?>
             </div>
            </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
<?php echo e($users->links()); ?>

<?php else: ?>
 <div class="d-flex justify-content-center align-items-center w-100" style="height: calc(100vh - 400px)" >
   <h4><?php echo app('translator')->get('No Users Found'); ?>!</h4>
 </div> 
<?php endif; ?>

</div>

<script>
  $(document).ready(function(){
    $('#print_options').on('change', function(){
      const option = $('#print_options').val();
      console.log(option)
      if(option === 'all-time'){
        $('#date_start').css('display','none')
        $('#date_end').css('display','none')
      }else{
        $('#date_start').css('display','flex')
        $('#date_end').css('display','flex')
      }
    });
  });
</script>

<script>
$(document).ready(function(){
 $('#pdf-form').on('submit',function(){
  $('#loader-download').removeClass('d-none');
   $('#download-txt').addClass('d-none');  
 });
});
</script>

 <!-- Invest Modal -->
<div class="modal fade" id="client-export">
 <div class="modal-dialog">
  <div class="modal-content">
   <form action="<?php echo e(url('/admin/export-clients-pdf')); ?>" method="POST" id="pdf-form" style="gap:10px" class="d-flex me-5 flex-column align-items-center justify-content-center my-2 mx-4" >
   <?php echo csrf_field(); ?>
   <div class="d-flex flex-column align-items-center" style="width:50%" >
    <h4 style="font-size:16px;align-self:start" ><?php echo app('translator')->get('Filter'); ?></h4>
   <select id="print_options" name="print-options" class="form-control" style="width:100%" >
    <option value="all-time"><?php echo app('translator')->get('All Time'); ?></option>
    <option value="by-date" ><?php echo app('translator')->get('By Date'); ?></option>
   </select>
</div>
   <div id="date_start" class="flex-column align-items-center" style="display:none;width:50%" >
    <h4 style="font-size:16px;align-self:start" ><?php echo app('translator')->get('Start Date'); ?></h4>
    <input type="date" name="date_start" class="form-control" style="width:100%" />
   </div>
   <div id="date_end" class="flex-column align-items-center" style="display:none;width:50%" >
    <h4 style="font-size:16px;align-self:start" ><?php echo app('translator')->get('End Date'); ?></h4>
    <input type="date" name="date_end" class="form-control" style="width:100%" />    
   </div>
   <div class="d-flex me-5 w-100 justify-content-center" >
    <button class="btn px-3 py-2" style="color:white;background-color:#D5924D;margin-left:10px;border-radius:5px;height:40px">
     <span id="download-txt" ><?php echo app('translator')->get('Download'); ?></span>
     <div id="loader-download" class="d-none">
      <div class="spinner-border" style="width:14px;height:14px" role="status"><span class="sr-only">Loading...</span></div>
     </div>
    </button>
   </div> 
  </form> 
 </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminDashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dar Al-Iskan Real Estate\resources\views/adminDashboard/ManageUsers.blade.php ENDPATH**/ ?>