@vite(['resources/js/jquery-3.6.0.min.js', 'resources/js/bootstrap.min.js', 'resources/js/viewport.jquery.js', 'resources/js/odometer.min.js', 'resources/js/lightbox.min.js', 'resources/js/owl.min.js', 'resources/js/toastr.min.js', 'resources/js/notify.js', 'resources/js/main.js', 'resources/js/custom.js'])
</body>
</html>
