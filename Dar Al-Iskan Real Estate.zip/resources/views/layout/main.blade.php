@include('layout.navbar')
@yield('main')